document.addEventListener("DOMContentLoaded", () => {
    // Pobranie głównego kontenera oraz utworzenie panelu użytkownika (w prawym górnym rogu)
    const mainContent = document.getElementById("main-content");
    const userPanel = document.createElement("div");
    userPanel.id = "user-panel";
    userPanel.style.position = "absolute";
    userPanel.style.top = "10px";
    userPanel.style.right = "10px";
    document.body.appendChild(userPanel);
    let currentUser = null;
  
    const routes = {
      home: showHome,
      login: showLogin,
      register: showRegister,
      game: showGameMenu,
      shell: showShellGame,
      tictactoe: showTicTacToe
    };
  
    document.querySelectorAll("nav a").forEach(link => {
      link.addEventListener("click", event => {
        event.preventDefault();
        // np. "login-link" → "login"
        const route = event.target.id.replace("-link", "");
        if (routes[route]) routes[route]();
      });
    });
  
    // Inicjalizacja startowa: wyświetlenie strony głównej i aktualizacja panelu użytkownika
    routes.home();
    updateUserPanel();
  
    // Widok strony głównej
    function showHome() {
      mainContent.innerHTML = `
        <h1>Witamy w grach webowych!</h1>
        <p>Wybierz opcję z menu powyżej, aby rozpocząć.</p>
      `;
    }
  
    // Widok logowania
    function showLogin() {
      mainContent.innerHTML = `
        <h1>Logowanie</h1>
        <form id="login-form">
          <input type="text" id="login-username" placeholder="Nazwa użytkownika" required>
          <input type="password" id="login-password" placeholder="Hasło" required>
          <button type="submit">Zaloguj się</button>
        </form>
        <p id="login-message"></p>
      `;
      document.getElementById("login-form").addEventListener("submit", e => {
        e.preventDefault();
        const username = document.getElementById("login-username").value.trim();
        const password = document.getElementById("login-password").value;
        loginUser(username, password);
      });
    }
  
    // Widok rejestracji
    function showRegister() {
      mainContent.innerHTML = `
        <h1>Rejestracja</h1>
        <form id="register-form">
          <input type="text" id="register-username" placeholder="Nazwa użytkownika" required>
          <input type="password" id="register-password" placeholder="Hasło" required>
          <button type="submit">Zarejestruj się</button>
        </form>
        <p id="register-message"></p>
      `;
      document.getElementById("register-form").addEventListener("submit", e => {
        e.preventDefault();
        const username = document.getElementById("register-username").value.trim();
        const password = document.getElementById("register-password").value;
        registerUser(username, password);
      });
    }
  
    // Widok menu gier Memory
    function showGameMenu() {
      if (!currentUser) {
        alert("Musisz się zalogować, aby grać!");
        return routes.login();
      }
      mainContent.innerHTML = `
        <h1>Wybierz poziom trudności gry Memory</h1>
        <div id="difficulty-container" style="display: flex; gap: 10px; justify-content: center; margin-top: 20px;">
          <button data-level="easy">Łatwy</button>
          <button data-level="medium">Średni</button>
          <button data-level="hard">Trudny</button>
        </div>
      `;
      document.querySelectorAll("#difficulty-container button").forEach(button => {
        button.addEventListener("click", () => startGame(button.dataset.level));
      });
    }
  
    // Widok gry Kubeczki – wybór poziomu trudności oraz uruchomienie gry
    function showShellGame() {
      if (!currentUser) {
        alert("Musisz się zalogować, aby grać!");
        return routes.login();
      }
      mainContent.innerHTML = `
        <h1>Wybierz poziom trudności (Kubeczki)</h1>
        <div id="difficulty-levels">
          <button data-level="easy">Łatwy (3 kubki)</button>
          <button data-level="medium">Średni (5 kubków)</button>
          <button data-level="hard">Trudny (7 kubków)</button>
        </div>
        <p id="shell-message" style="margin-top: 20px;"></p>
        <button id="play-shell-again" style="display: none;">Zagraj ponownie</button>
      `;
      document.querySelectorAll("#difficulty-levels button").forEach(button => {
        button.addEventListener("click", () => startShellGame(button.dataset.level));
      });
    
      // Funkcja rozpoczynająca grę w Kubeczeki
      function startShellGame(level) {
        document.getElementById("difficulty-levels").style.display = "none";
        let numCups = (level === "easy") ? 3 : (level === "medium") ? 5 : 7;
        const cupsContainer = document.createElement("div");
        cupsContainer.id = "shell-cups";
        cupsContainer.style.display = "flex";
        cupsContainer.style.justifyContent = "center";
        cupsContainer.style.gap = "30px";
        cupsContainer.style.marginTop = "30px";
        mainContent.appendChild(cupsContainer);
        const correctIndex = Math.floor(Math.random() * numCups);
        for (let i = 0; i < numCups; i++) {
          const cup = document.createElement("div");
          cup.style.width = "100px";
          cup.style.height = "100px";
          cup.style.background = "#b5651d";
          cup.style.borderRadius = "0 0 50px 50px";
          cup.style.cursor = "pointer";
          cup.style.display = "flex";
          cup.style.alignItems = "center";
          cup.style.justifyContent = "center";
          cup.textContent = "?";
          cup.dataset.index = i;
          cup.addEventListener("click", () => {
            document.querySelectorAll("#shell-cups div").forEach((el, idx) => {
              el.textContent = (idx == correctIndex) ? "TAK" : "NIE";
              el.style.pointerEvents = "none";
            });
            const message = document.getElementById("shell-message");
            message.textContent = (parseInt(cup.dataset.index) === correctIndex) ?
                                    "Brawo! Znalazłeś piłkę!" :
                                    "Pudło! Piłka była pod innym kubkiem.";
            document.getElementById("play-shell-again").style.display = "block";
          });
          cupsContainer.appendChild(cup);
        }
        document.getElementById("play-shell-again").addEventListener("click", showShellGame);
      }
    }
  
    // Widok gry Kółko i Krzyżyk
    function showTicTacToe() {
      if (!currentUser) {
        alert("Musisz się zalogować, aby grać!");
        return routes.login();
      }
      mainContent.innerHTML = `
        <h1>Kółko i Krzyżyk</h1>
        <p>Grasz jako X. Celem jest uzyskanie trzech X lub O w jednej linii!</p>
        <div id="tic-tac-toe-board" class="tic-tac-toe-board"></div>
        <p id="tic-tac-toe-message"></p>
        <button id="play-tic-tac-toe-again">Zagraj ponownie</button>
      `;
      const boardContainer = document.getElementById("tic-tac-toe-board");
      const message = document.getElementById("tic-tac-toe-message");
      let board = Array(9).fill(null);
      let currentPlayerSymbol = 'X';
      let gameActive = true;
    
      // Funkcja tworząca planszę gry do kółko i krzyżyk
      function createBoard() {
        boardContainer.innerHTML = '';
        board.forEach((value, index) => {
          const cell = document.createElement("div");
          cell.classList.add("cell");
          cell.style.width = "100px";
          cell.style.height = "100px";
          cell.style.display = "flex";
          cell.style.alignItems = "center";
          cell.style.justifyContent = "center";
          cell.style.backgroundColor = "#ddd";
          cell.style.fontSize = "2rem";
          cell.style.cursor = "pointer";
          cell.style.color = "black";
          cell.textContent = value ? value : "";
          cell.addEventListener("click", () => handleCellClick(index));
          boardContainer.appendChild(cell);
        });
      }
    
      function handleCellClick(index) {
        if (!gameActive || board[index]) return;
        board[index] = currentPlayerSymbol;
        currentPlayerSymbol = (currentPlayerSymbol === 'X') ? 'O' : 'X';
        checkWinner();
        createBoard();
      }
    
      function checkWinner() {
        const winningComb = [
          [0, 1, 2], [3, 4, 5], [6, 7, 8],
          [0, 3, 6], [1, 4, 7], [2, 5, 8],
          [0, 4, 8], [2, 4, 6]
        ];
        for (let comb of winningComb) {
          const [a, b, c] = comb;
          if (board[a] && board[a] === board[b] && board[a] === board[c]) {
            message.textContent = `${board[a]} wygrał!`;
            gameActive = false;
            return;
          }
        }
        if (!board.includes(null)) {
          message.textContent = "Remis!";
          gameActive = false;
        }
      }
    
      createBoard();
      document.getElementById("play-tic-tac-toe-again")
        .addEventListener("click", showTicTacToe);
    }
        
    // Funkcja rejestracji użytkownika
    function registerUser(username, password) {
      fetch('register.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      })
        .then(response => response.json())
        .then(data => {
          const regMsg = document.getElementById("register-message");
          if (data.success) {
            regMsg.textContent = "Rejestracja udana! Możesz się teraz zalogować.";
            setTimeout(() => routes.login(), 1000);
          } else {
            regMsg.textContent = data.message || "Rejestracja nie powiodła się.";
          }
        });
    }
    
    // Funkcja logowania użytkownika
    function loginUser(username, password) {
      fetch('login.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      })
        .then(response => response.json())
        .then(data => {
          const loginMsg = document.getElementById("login-message");
          if (data.success) {
            currentUser = data.username;
            loginMsg.textContent = "Zalogowano pomyślnie.";
            updateUserPanel();
            routes.home();
          } else {
            loginMsg.textContent = data.message || "Nieprawidłowe dane logowania.";
          }
        });
    }
    
    // Funkcja wywołująca zmianę hasła
    function showChangePassword() {
      mainContent.innerHTML = `
        <h1>Zmień hasło</h1>
        <form id="change-password-form">
          <input type="password" id="new-password" placeholder="Nowe hasło" required>
          <button type="submit">Zmień hasło</button>
        </form>
        <p id="change-password-message"></p>
      `;
      document.getElementById("change-password-form").addEventListener("submit", e => {
        e.preventDefault();
        const newPassword = document.getElementById("new-password").value;
        fetch("change_password.php", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username: currentUser, password: newPassword })
        })
          .then(response => response.json())
          .then(data => {
            const cpMsg = document.getElementById("change-password-message");
            cpMsg.textContent = data.message || "Nie udało się zmienić hasła.";
          });
      });
    }
    
    // Funkcja wylogowywania
    function logoutUser() {
      currentUser = null;
      updateUserPanel();
      alert("Wylogowano pomyślnie.");
      routes.home();
    }
    
    // Funkcja aktualizująca panel użytkownika
    function updateUserPanel() {
      if (currentUser) {
        userPanel.innerHTML = `
          <span>Witaj, ${currentUser}</span>
          <button id="change-password">Zmień hasło</button>
          <button id="logout">Wyloguj</button>
        `;
        document.getElementById("change-password")
          .addEventListener("click", showChangePassword);
        document.getElementById("logout")
          .addEventListener("click", logoutUser);
      } else {
        userPanel.innerHTML = "";
      }
    }
        
    // Funkcja rozpoczynająca grę Memory
    function startGame(level) {
      mainContent.innerHTML = `
        <h1>Poziom: ${level}</h1>
        <p>Znajdź wszystkie pary kart!</p>
        <p id="moves-left"></p>
        <div id="game-board" class="game-board"></div>
      `;
      const cards = generateCards(8);
      const gameBoard = document.getElementById("game-board");
      const movesLeftElement = document.getElementById("moves-left");
    
      let flippedCards = [];
      let matchedPairs = 0;
      let maxMoves = (level === "medium") ? 25 : (level === "hard") ? 15 : Infinity;
      let movesLeft = maxMoves;
      let isChecking = false;
    
      updateMovesLeft();
  
      cards.forEach(num => {
        const card = createCard(num);
        gameBoard.appendChild(card);
      });
    
      // Funkcja generująca karty 
      function generateCards(pairs) {
        const nums = Array.from({ length: pairs }, (_, i) => i + 1).flatMap(x => [x, x]);
        return nums.sort(() => Math.random() - 0.5);
      }
    
      function createCard(num) {
        const card = document.createElement("div");
        card.className = "card";
        card.dataset.number = num;
        card.textContent = "?";
        card.addEventListener("click", () => flipCard(card));
        return card;
      }
    
      function flipCard(card) {
        if (isChecking || card.classList.contains("flipped") || card.classList.contains("matched"))
          return;
    
        card.classList.add("flipped");
        card.textContent = card.dataset.number;
        flippedCards.push(card);
    
        if (flippedCards.length === 2) {
          isChecking = true;
          const [first, second] = flippedCards;
          if (first.dataset.number === second.dataset.number) {
            first.classList.add("matched");
            second.classList.add("matched");
            matchedPairs++;
            if (matchedPairs === cards.length / 2) {
              setTimeout(() => {
                alert("Gratulacje! Wygrałeś!");
                showGameMenu();
              }, 500);
            }
            flippedCards = [];
            isChecking = false;
          } else {
            setTimeout(() => {
              first.classList.remove("flipped");
              second.classList.remove("flipped");
              first.textContent = "?";
              second.textContent = "?";
              flippedCards = [];
              isChecking = false;
            }, 1000);
          }
          movesLeft--;
          updateMovesLeft();
          if (movesLeft <= 0) {
            setTimeout(() => {
              alert("Przegrałeś! Wyczerpałeś liczbę ruchów.");
              showGameMenu();
            }, 500);
          }
        }
      }
    
      function updateMovesLeft() {
        movesLeftElement.textContent = `Pozostałe ruchy: ${movesLeft === Infinity ? "nieskończoność" : movesLeft}`;
      }
    }
  });  