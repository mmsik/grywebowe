<?php
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

$username = $data['username'];
$password = $data['password'];

$servername = "localhost";
$usernameDB = "root"; 
$passwordDB = ""; 
$dbname = "memory_game"; 

$conn = new mysqli($servername, $usernameDB, $passwordDB, $dbname);


if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Błąd połączenia z bazą danych"]));
}


$sql = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    
    echo json_encode(["success" => false, "message" => "Nazwa użytkownika już istnieje. Wybierz inną."]);
} else {
    
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $hashedPassword);

    if ($stmt->execute()) {
        echo json_encode(["success" => true, "message" => "Rejestracja zakończona sukcesem!"]);
    } else {
        echo json_encode(["success" => false, "message" => "Błąd rejestracji, spróbuj ponownie."]);
    }
}


$conn->close();
?>
