<?php
header('Content-Type: application/json');

$host = 'localhost';
$user = 'root'; 
$password = '';
$dbname = 'memory_game';

$conn = new mysqli($host, $user, $password, $dbname);


if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Błąd połączenia z bazą danych.']));
}

$data = json_decode(file_get_contents('php://input'), true);
$username = $data['username'];
$password = $data['password'];

$sql = "SELECT * FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    
    if (password_verify($password, $user['password'])) {
        echo json_encode(['success' => true, 'username' => $username]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Nieprawidłowe hasło.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Użytkownik nie istnieje.']);
}

$stmt->close();
$conn->close();
?>
