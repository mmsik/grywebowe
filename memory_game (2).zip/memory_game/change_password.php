<?php
header('Content-Type: application/json');

$host = 'localhost';
$db = 'memory_game';
$user = 'root';
$pass = '';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Błąd połączenia z bazą danych."]));
}

$data = json_decode(file_get_contents("php://input"));
$username = $conn->real_escape_string($data->username);
$password = password_hash($data->password, PASSWORD_BCRYPT);

$sql = "UPDATE users SET password='$password' WHERE username='$username'";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true, "message" => "Hasło zmienione pomyślnie."]);
} else {
    echo json_encode(["success" => false, "message" => "Błąd podczas zmiany hasła."]);
}

$conn->close();
?>
